﻿// 사용자로부터 5개의 숫자를 입력 받아 배열에 저장하고 이들의 합계와 평균을 계산해서 출력해주세요!

#include <iostream>

int Sum(int* arr, int length)
{
	int sum{};
	for (int i = 0; i < length; i++)
		sum += arr[i];
	return sum;
}

int Average(int arr[5], int length)
{
	int aver{};
	for (int i = 0; i < length; i++)
		aver += arr[i];

	return aver/ length;
}


int main()
{
	int arr[100]{};
	int length{};

	std::cout << "배열의 길이를 입력하세요!!" << std::endl;
	std::cin >> length;

	for (int i = 0; i < length; i++)
		std::cin >> arr[i];

	std::cout << "Sum : " << Sum(arr, length) << std::endl;
	std::cout << "Average : " << Average(arr, length) << std::endl;
}
